let app = Vue.createApp({
    data: function(){
        return{
            message: 'String Manipulation',
            normal:'',
            lower:'',
            upper:''
        }
    },
    methods: {
        showWord(){
            var word = document.getElementById("inp").value;
            
            this.normal = word;
            this.lower = word.toLowerCase();
            this.upper = word.toUpperCase();
        }
    }
})
app.mount('#app')